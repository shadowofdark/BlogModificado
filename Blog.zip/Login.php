<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login</title>
<meta name="Key" content="Registro"/>
<link href="CSS/Style.css" rel="stylesheet" type="text/css"/>
</head>
<body>
    
<form class="box" name="form1" method="post" action="iniciar.php">
<legend>Ingrese sus datos del Blog</legend>
  
	<input type="text" placeholder="nombre de usuario" name="username">
	<input type="password" placeholder="Contraseña" name="password">
	<input type="submit" value="Iniciar Sesion">
	

    <div class="credits"></div>
  </form> 


</body>
</html>
