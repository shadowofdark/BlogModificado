<?php


      session_name('data');
       session_start();
    
     $usuario = $_SESSION['user_login'];
     
   
     



if(isset($usuario)){
    echo "Bienvenido,",$usuario;}


$conexion = mysqli_connect("localhost","root","testuda321") 
                    or  die("Problemas en la conexion");

mysqli_select_db($conexion,"tiki15svn") 
                    or  die("Problemas en la selección de la base de datos");
?>

<!DOCTYPE html>
<html lang="es">

<head>
    
    <meta charset="utf-8">
    <title Blog CSCW></title>
    
    <link href="CSS/blog.css" rel="stylesheet">
    <link href="CSS/bootstrap.css" rel="stylesheet">
    
    
    <script src="JS/bootstrap.js"></script>
          <script src="JS/jquery.js"></script>
          <script src="JS/jquery.flexslider.js"></script>
            <script src="JS/javascript.js"></script>
        <script src="JS/bootstrap-modal.js"></script>
    <script type="text/javascript" src="JS/jquery.scrollTo.min.js"></script>
    <script src="JS/admin.js" type="text/javascript"></script>
    
   

    
</head>

    <body>
    
         <!-- BARRA DE NAVEGACION -->
           <nav class="navbar navbar-inverse navbar-fixed-top">
               <div class="container">
                <div class="navbar-header">
                <a class="navbar-brand" align=left >CS-Blog-CW!</a>
                   </div>
                   <div id="navbar" class="collapse navbar-collapse">
                       
                       <!--Parte izquierda de Navbar -->
                   <ul class="nav navbar-nav">
                        <li ><a href="index.php">Home</a></li>
                        
                       <li><a href="mensajes.php">Mensajes</a></li>
                       <li class="active"><a  href="archivos.php">Archivos</a></li>
                       <li><a></a></li>
                       <li><a></a></li>
                       <li><a></a></li>
                       <li><a></a></li>
                       <li><a></a></li>
                       <li><a></a></li>
                       <li><a style="font-size:15px;">Hola <?php echo $usuario; ?>!</a></li>
                   </ul>
                       
                      
                       
                       <!--Parte derecha de Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="salir.php"><button class="btn btn-primary"  type="button" >Salir</button></a>
                        </li>
                       </ul>
                
                </div>
                </div>
               
               
            
        </nav>

        <!-- FIN BARRA DE NAVEGACION -->
<form action="ftp_enviar.php"method="post" enctype="multipart/form-data" style="margin-top:50px;">
		<div>Archivo: <input type="file" name="file" id="file" maxlength="45"></div>
		<dif><input type="submit" name="enviar" value="enviar"/></div>
	</form>
        "<div style="; margin-left:300px; margin-top: 50px;" >
        <h1 class="page-header">Documentos</h1> 
        
            
         <table class="table table-striped">
              <thead>
                <tr>
                  <th><h3>Nombre</h3></th>
                  <th><h3>Usuario</h3></th>
                  <th><h3>Ruta</h3></th><!-- Visto o No Visto -->
                  
                       
                </tr>
              </thead>
              <tbody>
                  
        <?php 
        

         $resultDoc = mysqli_query($conexion,"SELECT * FROM archivos WHERE user='$usuario'"); 

                  $datosDoc = mysqli_fetch_array($resultDoc);
                  
        
       // $conn_id = @ftp_connect($host, $port);
//if ($conn_id) {
    # Realizamos el login con nuestro usuario y contraseña
  //  if (@ftp_login($conn_id, $user, $password)) {
        # Canviamos al directorio especificado
     //   if (@ftp_chdir($conn_id, $path)) {
        
 
               
      
                 
                 
while($datosDoc)
{
    
    $ruta = "/home/ubuntu/archivos/$usuario";
        
    
echo "<tr>";
echo "<th>".$datosDoc['documento']."</th>";
echo "<th>".$datosDoc['user']."</th>";

echo "<th>".$datosDoc['nombre']."</th>";

echo "<td><a href='eliminar.php?nombre=".$datosDoc["documento"]."&id=".$datosDoc["id"]."'>Borrar</a></td>";
    
echo "<td><a href='descargar.php?nombre=".$datosDoc["documento"]."'>Descargar</a></td>";

//echo "<th><button type='button'><a href='descarga.php'><img class='img-thumbnail img-circle' src='img/descarga1.jpg' height='50' width='50'/></a></button></th>"; 

//echo "<th><button class='btn btn-primary' type='button' id=",$datosDoc['id']," onClick='MarcarDoc(this.id)'>Marcar visto</button></th>";  

$datosDoc = mysqli_fetch_array($resultDoc);
    
echo "</tr>";
}
// cerrar la conexión ftp


// imprimir el contenido del buffer
     //   }else{
       //     echo $path;
     //       echo "Problema en la ruta de archivo";
   //     }ftp_close($conn_id);
   // }else{
    //    echo "problema con usuario o contraseña";
  //  }
//}else{
   // echo "problema en la conexion";
//}

?>
                  
             </tbody>
    </body>
</html>
