<?php


      session_name('data');
       session_start();
    
     $usuario = $_SESSION['user_login'];

    $id = $_GET["id"];
    $file = $_GET["nombre"];
    

if(isset($usuario)){
    echo "Bienvenido,",$usuario;}


$conexion = mysqli_connect("localhost","root","testuda321") 
                    or  die("Problemas en la conexion");

mysqli_select_db($conexion,"tikidb") 
                    or  die("Problemas en la selección de la base de datos");
    

$host = "192.168.197.101";
$port = 21;
$user = "guille";
$password = "testuda321";
$ruta = "/home/ubuntu/archivos/$usuario";

$conn_id = @ftp_connect($host, $port);
if ($conn_id) {
   
    if (@ftp_login($conn_id, $user, $password)) {
        
        $completo="$ruta/$file";
        
       $insert= mysqli_query($conexion,"DELETE FROM archivos WHERE id='$id'")  or die ("problemas al borrar".mysql_error());
        
   if (ftp_delete($conn_id, $completo)) {
 echo "$file se ha eliminado satisfactoriamente\n";
} else {
 echo "No se pudo eliminar $completo\n";
}

        
header('Location:archivos.php');
      
    }
}
    
                   

// cerrar la conexión ftp
ftp_close($conn_id);
?>