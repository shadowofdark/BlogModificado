<?php 

session_name('data');
       session_start();
    
$usuario=$_SESSION['user_login'];

$conexion = mysqli_connect("localhost","root","testuda321") 
                    or  die("Problemas en la conexion");

mysqli_select_db($conexion,"tikidb") 
                    or  die("Problemas en la selección de la base de datos");

     
    $estado=0;
     session_destroy();
       
        $update= mysqli_query($conexion,"UPDATE users_users SET user_status='$estado' WHERE login='$usuario'");
       
       //echo "Has cerrado la sesion";
header('Location: Login.php');
       
   
?>
