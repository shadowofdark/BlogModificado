<?php


      session_name('data');
       session_start();
    
     $usuario = $_SESSION['user_login'];

  
    $file = $_GET["nombre"];
    $user = $_GET["user"];

if(isset($usuario)){
    echo "Bienvenido,",$usuario;}


$conexion = mysqli_connect("localhost","root","1234") 
                    or  die("Problemas en la conexion");

mysqli_select_db($conexion,"wordpress") 
                    or  die("Problemas en la selección de la base de datos");
    

$local_file = $_GET['nombre']; //Nombre archivo en nuestro PC
$server_file = "/home/ubuntu/archivos/" . $user . "/"; //Nombre archivo en FTP


$host = "192.168.174.3";
$port = 21;
$user = "elio";
$password = "1234";
$ruta = "/home/ubuntu/archivos/$user";

$conn_id = @ftp_connect($host, $port);
if ($conn_id) {
    # Realizamos el login con nuestro usuario y contraseña
    if (@ftp_login($conn_id, $user, $password)) {
        
        
      @ftp_chdir($conn_id, $server_file);
header("Content-Disposition: attachment; filename=$file\n\n");
header("Content-Type: application/octet-stream");
header("Content-Length: " . filesize($server_file));
ftp_close($conn_id);
//header('Location:archivos.php');
      
    }else{
      echo "error en la conexion de usuario y contraseña";
    }
}else{
    echo "error en la conexion de numero de puerto y direccion";
}
    
                   

// cerrar la conexión ftp
ftp_close($conn_id);
?>